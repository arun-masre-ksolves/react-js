import React from "react";
import { useSelector } from "react-redux";

const Cart = () => {
  const items = useSelector(state => state);
  console.log(items);
  return (
    <div className="alert alert-success">
      <h3 className="text-center">
        Total Items: Total Items: {items.Cart.lenght} (Rs. 3400)/-
      </h3>
    </div>
  );
};

export default Cart;
